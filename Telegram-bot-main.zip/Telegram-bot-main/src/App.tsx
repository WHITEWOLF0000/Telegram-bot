const App = () => {
  return (
    <div className="text-center text-3xl text-blue-600 mt-20">
      Hello, Netlify + React + Vite + Tailwind!
    </div>
  );
};

export default App;
