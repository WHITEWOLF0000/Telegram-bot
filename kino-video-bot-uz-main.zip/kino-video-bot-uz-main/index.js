import TelegramBot from 'node-telegram-bot-api';

// Bot tokeningizni kiriting
const token = '7871629317:AAECmxOP_3t3GJraePJh5zny6yteyHEStr8';
const bot = new TelegramBot(token, { polling: true });

// /start komandasi
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;

  const welcomeMessage = `🇺🇿 Kinolarni qidirish uchun pastdagi tugmani bosing.\n🇺🇸 Click the button below to search for movies.\n🇷🇺 Нажмите кнопку ниже, чтобы найти фильмы.`;
bot.start(ctx => {
    ctx.replyWithHTML(
        `🇺🇿 Kinolarni qidirish uchun pastdagi tugmani bosing.\n🇺🇸 Click the button below to search for movies.\n🇷🇺 Нажмите кнопку ниже, чтобы найти фильмы.`,
        Markup.inlineKeyboard([[Markup.button.webApp(`Kinoni ko'rish', 'https://youtube.com/`)]])
    )
})

  bot.sendMessage(chatId, welcomeMessage, options);
});
