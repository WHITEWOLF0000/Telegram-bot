
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';

interface GenreFilterProps {
  selectedGenre: string | null;
  onGenreSelect: (genre: string | null) => void;
}

const GenreFilter = ({ selectedGenre, onGenreSelect }: GenreFilterProps) => {
  const { language } = useLanguage();

  const genres = [
    { id: 'Jangari', uz: 'Jangari', en: 'Action', ru: 'Боевик' },
    { id: 'Drama', uz: 'Drama', en: 'Drama', ru: 'Драма' },
    { id: 'Komediya', uz: 'Komediya', en: 'Comedy', ru: 'Комедия' },
    { id: 'Melodrama', uz: 'Melodrama', en: 'Romance', ru: 'Мелодрама' },
    { id: 'Sarguzasht', uz: 'Sarguzasht', en: 'Adventure', ru: 'Приключения' },
    { id: "Qo'rqinchli", uz: "Qo'rqinchli", en: 'Horror', ru: 'Ужасы' },
    { id: 'Tarixiy', uz: 'Tarixiy', en: 'History', ru: 'Исторический' },
    { id: 'Klassika', uz: 'Klassika', en: 'Classic', ru: 'Классика' },
    { id: 'Fantastika', uz: 'Fantastika', en: 'Sci-Fi', ru: 'Фантастика' },
    { id: 'Hayotiy', uz: 'Hayotiy', en: 'Biography', ru: 'Биография' },
    { id: 'Triller', uz: 'Triller', en: 'Thriller', ru: 'Триллер' },
    { id: 'Detektiv', uz: 'Detektiv', en: 'Crime', ru: 'Детектив' },
    { id: 'Hujjatli film', uz: 'Hujjatli film', en: 'Documentary', ru: 'Документальный' },
    { id: 'Anime', uz: 'Anime', en: 'Anime', ru: 'Аниме' },
    { id: 'Kriminal', uz: 'Kriminal', en: 'Crime', ru: 'Криминал' },
    { id: 'Fentezi', uz: 'Fentezi', en: 'Fantasy', ru: 'Фэнтези' },
    { id: 'Afsona', uz: 'Afsona', en: 'Fantasy', ru: 'Сказка' },
    { id: 'Vester', uz: 'Vester', en: 'Western', ru: 'Вестерн' },
    { id: 'Musiqiy', uz: 'Musiqiy', en: 'Musical', ru: 'Мюзикл' },
    { id: 'Family', uz: 'Oilaviy', en: 'Family', ru: 'Семейный' }
  ];

  const getGenreLabel = (genre: typeof genres[0]) => {
    switch (language) {
      case 'uz': return genre.uz;
      case 'en': return genre.en;
      case 'ru': return genre.ru;
      default: return genre.uz;
    }
  };

  const handleGenreClick = (genreId: string) => {
    // If the same genre is clicked, deselect it, otherwise select the new genre
    onGenreSelect(selectedGenre === genreId ? null : genreId);
  };

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3 text-gray-800">
        {language === 'uz' ? 'Janrlar' : language === 'en' ? 'Genres' : 'Жанры'}
      </h3>
      <div className="flex flex-wrap gap-2">
        {genres.map((genre) => (
          <Badge
            key={genre.id}
            variant={selectedGenre === genre.id ? "default" : "outline"}
            className={`cursor-pointer transition-all duration-200 ${
              selectedGenre === genre.id 
                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                : 'hover:bg-blue-100 hover:border-blue-300'
            }`}
            onClick={() => handleGenreClick(genre.id)}
          >
            {getGenreLabel(genre)}
          </Badge>
        ))}
      </div>
    </div>
  );
};

export default GenreFilter;
