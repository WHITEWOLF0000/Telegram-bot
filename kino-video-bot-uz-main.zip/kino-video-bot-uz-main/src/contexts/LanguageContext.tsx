import React, { createContext, useContext, useState, ReactNode } from 'react';
import { moviesDatabase } from '@/data/movies';

export type Language = 'uz' | 'en' | 'ru';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  getMovieTitle: (movieId: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  uz: {
    greeting: 'Salom! 👋 Men kino bot. Sizga kino kodi yuboring, men sizga videoni avtomatik yuklash uchun tayyorlayman.',
    availableCodes: 'Mavjud kino kodlari:',
    codeNotFound: 'Kechirasiz, "{code}" kodi topilmadi.',
    availableCodesError: 'Mavjud kodlar:',
    enterCorrectCode: 'Iltimos, to\'g\'ri kino kodini kiriting.',
    downloadingFile: '{title} fayli yuklanmoqda...',
    fileSize: 'Fayl hajmi: ~1.2GB',
    estimatedTime: 'Taxminiy vaqt: 2-3 daqiqa',
    downloadComplete: 'Yuklash tugallandi!',
    fileReady: 'Fayl tayyor - pastdagi tugma orqali yuklab oling',
    downloading: 'Yuklanmoqda...',
    ready: 'Tayyor!',
    download: 'Yuklab olish',
    watch: 'Ko\'rish',
    enterMovieCode: 'Kino kodini kiriting (masalan: uz001)',
    rating: 'Rating',
    genre: 'Janr',
    duration: 'Davomiyligi',
    selectLanguage: 'Tilni tanlang',
    language: 'Til',
    movieBot: 'Kino Bot',
    heroDescription: 'Kino kodini yuboring, men sizga kinoni yuboraman',
    telegramBot: 'Telegram Bot',
    botDescription: 'Kino kodini kiriting va darhol video oling. Oddiy va tez!',
    useBot: 'Botni ishlatish',
    movieCatalog: 'Kino Katalogi',
    catalogDescription: 'Barcha mavjud kinolar va ularning kodlarini ko\'ring',
    viewCatalog: 'Katalogni ko\'rish',
    howToUse: 'Qanday foydalanish?',
    step1Title: 'Katalogdan kod topish',
    step1Description: 'Kino katalogini ochib, kerakli filmni toping va kodini nusxalang',
    step2Title: 'Botga kod yuborish',
    step2Description: 'Telegram bot bo\'limiga o\'tib, kino kodini kiriting (masalan: uz001)',
    step3Title: 'Video olish',
    step3Description: 'Bot sizga kino haqida ma\'lumot va videoni yuboradi',
    tip: 'Maslahat: Har bir til uchun alohida kinolar mavjud',
    back: 'Orqaga',
    codeCopied: 'Kod nusxalandi!',
    codeClipboard: 'kodi clipboardga nusxalandi',
    error: 'Xatolik',
    copyError: 'Kodni nusxalashda xatolik yuz berdi',
    catalogInstruction: 'Botda foydalanish uchun kino kodini nusxalang va botga yuboring',
    searchPlaceholder: 'Kino nomi yoki kodi bilan qidirish...',
    copied: 'Nusxalandi',
    copyCode: 'Kod nusxalash',
    noMoviesFound: 'Hech qanday kino topilmadi'
  },
  en: {
    greeting: 'Hello! 👋 I\'m a movie bot. Send me a movie code and I\'ll prepare the video for automatic download.',
    availableCodes: 'Available movie codes:',
    codeNotFound: 'Sorry, code "{code}" not found.',
    availableCodesError: 'Available codes:',
    enterCorrectCode: 'Please enter the correct movie code.',
    downloadingFile: '{title} file is downloading...',
    fileSize: 'File size: ~1.2GB',
    estimatedTime: 'Estimated time: 2-3 minutes',
    downloadComplete: 'Download completed!',
    fileReady: 'File ready - download using the button below',
    downloading: 'Downloading...',
    ready: 'Ready!',
    download: 'Download',
    watch: 'Watch',
    enterMovieCode: 'Enter movie code (example: en001)',
    rating: 'Rating',
    genre: 'Genre',
    duration: 'Duration',
    selectLanguage: 'Select Language',
    language: 'Language',
    movieBot: 'Movie Bot',
    heroDescription: 'Send movie code and I\'ll send you the movie',
    telegramBot: 'Telegram Bot',
    botDescription: 'Enter movie code and get video instantly. Simple and fast!',
    useBot: 'Use Bot',
    movieCatalog: 'Movie Catalog',
    catalogDescription: 'View all available movies and their codes',
    viewCatalog: 'View Catalog',
    howToUse: 'How to use?',
    step1Title: 'Find code from catalog',
    step1Description: 'Open movie catalog, find the desired film and copy its code',
    step2Title: 'Send code to bot',
    step2Description: 'Go to Telegram bot section and enter movie code (example: en001)',
    step3Title: 'Get video',
    step3Description: 'Bot will send you movie information and video',
    tip: 'Tip: Each language has different movies available',
    back: 'Back',
    codeCopied: 'Code copied!',
    codeClipboard: 'code copied to clipboard',
    error: 'Error',
    copyError: 'Error copying code',
    catalogInstruction: 'Copy movie code and send to bot for use',
    searchPlaceholder: 'Search by movie name or code...',
    copied: 'Copied',
    copyCode: 'Copy Code',
    noMoviesFound: 'No movies found'
  },
  ru: {
    greeting: 'Привет! 👋 Я кино-бот. Отправьте мне код фильма, и я подготовлю видео для автоматической загрузки.',
    availableCodes: 'Доступные коды фильмов:',
    codeNotFound: 'Извините, код "{code}" не найден.',
    availableCodesError: 'Доступные коды:',
    enterCorrectCode: 'Пожалуйста, введите правильный код фильма.',
    downloadingFile: 'Файл {title} загружается...',
    fileSize: 'Размер файла: ~1.2GB',
    estimatedTime: 'Примерное время: 2-3 минуты',
    downloadComplete: 'Загрузка завершена!',
    fileReady: 'Файл готов - скачайте, используя кнопку ниже',
    downloading: 'Загружается...',
    ready: 'Готово!',
    download: 'Скачать',
    watch: 'Смотреть',
    enterMovieCode: 'Введите код фильма (например: ru001)',
    rating: 'Рейтинг',
    genre: 'Жанр',
    duration: 'Продолжительность',
    selectLanguage: 'Выберите язык',
    language: 'Язык',
    movieBot: 'Кино Бот',
    heroDescription: 'Отправьте код фильма, и я пришлю вам кино',
    telegramBot: 'Telegram Бот',
    botDescription: 'Введите код фильма и мгновенно получите видео. Просто и быстро!',
    useBot: 'Использовать бота',
    movieCatalog: 'Каталог фильмов',
    catalogDescription: 'Просмотрите все доступные фильмы и их коды',
    viewCatalog: 'Посмотреть каталог',
    howToUse: 'Как использовать?',
    step1Title: 'Найти код в каталоге',
    step1Description: 'Откройте каталог фильмов, найдите нужный фильм и скопируйте его код',
    step2Title: 'Отправить код боту',
    step2Description: 'Перейдите в раздел Telegram бота и введите код фильма (например: ru001)',
    step3Title: 'Получить видео',
    step3Description: 'Бот отправит вам информацию о фильме и видео',
    tip: 'Совет: Для каждого языка доступны разные фильмы',
    back: 'Назад',
    codeCopied: 'Код скопирован!',
    codeClipboard: 'код скопирован в буфер обмена',
    error: 'Ошибка',
    copyError: 'Ошибка при копировании кода',
    catalogInstruction: 'Скопируйте код фильма и отправьте боту для использования',
    searchPlaceholder: 'Поиск по названию фильма или коду...',
    copied: 'Скопировано',
    copyCode: 'Копировать код',
    noMoviesFound: 'Фильмы не найдены'
  }
};

const movieTitles = {
  uz: {
    "001": "Shoushenk qamoqxonasidan qochish",
    "002": "Krestnyy otets",
    "003": "Qorong'u ritsar",
    "004": "Arzon fantastika",
    "005": "Forrest Gamp",
    "006": "Shindlerning ro'yxati",
    "007": "Uzuklar hukmdori: Qirolning qaytishi",
    "008": "Boshlanish",
    "009": "Matritsa",
    "010": "Yaxshi yigitlar",
    "011": "Jang klubi",
    "012": "Qo'zilarning sukunati",
    "013": "Titanic",
    "014": "Avatar",
    "015": "Qora pantera",
    "016": "Joker",
    "017": "Interstellar"
  },
  en: {
    "001": "The Shawshank Redemption",
    "002": "The Godfather",
    "003": "The Dark Knight",
    "004": "Pulp Fiction",
    "005": "Forrest Gump",
    "006": "Schindler's List",
    "007": "The Lord of the Rings: The Return of the King",
    "008": "Inception",
    "009": "The Matrix",
    "010": "Goodfellas",
    "011": "Fight Club",
    "012": "The Silence of the Lambs",
    "013": "Titanic",
    "014": "Avatar",
    "015": "Black Panther",
    "016": "Joker",
    "017": "Interstellar"
  },
  ru: {
    "001": "Побег из Шоушенка",
    "002": "Крестный отец",
    "003": "Темный рыцарь",
    "004": "Криминальное чтиво",
    "005": "Форрест Гамп",
    "006": "Список Шиндлера",
    "007": "Властелин колец: Возвращение короля",
    "008": "Начало",
    "009": "Матрица",
    "010": "Славные парни",
    "011": "Бойцовский клуб",
    "012": "Молчание ягнят",
    "013": "Титаник",
    "014": "Аватар",
    "015": "Черная пантера",
    "016": "Джокер",
    "017": "Интерстеллар"
  }
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('uz');

  const t = (key: string): string => {
    const translation = translations[language][key as keyof typeof translations['uz']];
    if (!translation) {
      console.warn(`Translation missing for key: ${key} in language: ${language}`);
      return key;
    }
    return translation;
  };

  const getMovieTitle = (movieId: string): string => {
    const movie = moviesDatabase.find(m => m.id === movieId);
    if (!movie) return movieId;
    
    // Return the appropriate title based on current language
    if (language === 'uz') return movie.titleUz;
    if (language === 'en') return movie.title;
    if (language === 'ru') return movie.title; // For Russian movies, use the original title
    
    return movie.title;
  };

  const value = {
    language,
    setLanguage,
    t,
    getMovieTitle
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
