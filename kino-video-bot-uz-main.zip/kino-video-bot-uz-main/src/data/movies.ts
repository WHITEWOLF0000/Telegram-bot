
export interface Movie {
  id: string;
  title: string;
  titleUz: string;
  year: number;
  genre: string[];
  rating: number;
  videoUrl: string;
  thumbnail: string;
  description: string;
  descriptionUz: string;
  duration: string;
  language: 'uz' | 'en' | 'ru';
}

export const moviesDatabase: Movie[] = [
  // O'zbek kinolari
  {
    id: "uz001",
    title: "Sevgi qissasi",
    titleUz: "Sevgi qissasi",
    year: 2023,
    genre: ["Drama", "Romance"],
    rating: 8.5,
    videoUrl: "https://archive.org/download/SevgiQissasi/Sevgi%20Qissasi.mp4",
    thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
    description: "O'zbek oilasining muhabbat va sadoqat haqidagi hikoyasi",
    descriptionUz: "O'zbek oilasining muhabbat va sadoqat haqidagi hikoyasi",
    duration: "1h 45m",
    language: "uz"
  },
  {
    id: "uz002",
    title: "Toshkent kechalari",
    titleUz: "Toshkent kechalari",
    year: 2022,
    genre: ["Drama", "Crime"],
    rating: 8.2,
    videoUrl: "https://archive.org/download/ToshkentKechalari/Toshkent%20Kechalari.mp4",
    thumbnail: "https://images.unsplash.com/photo-1489599515378-c5e96e2c3c3e?w=400&h=600&fit=crop",
    description: "Toshkent ko'chalarida sodir bo'ladigan voqealar haqida",
    descriptionUz: "Toshkent ko'chalarida sodir bo'ladigan voqealar haqida",
    duration: "2h 10m",
    language: "uz"
  },
  {
    id: "uz003",
    title: "O'zbek baxtiyor",
    titleUz: "O'zbek baxtiyor",
    year: 2021,
    genre: ["Comedy", "Family"],
    rating: 7.8,
    videoUrl: "https://archive.org/download/OzbekBaxtiyor/Ozbek%20Baxtiyor.mp4",
    thumbnail: "https://images.unsplash.com/photo-1571847140471-1d7766e8f077?w=400&h=600&fit=crop",
    description: "O'zbek oilasining kulgili sarguzashtlari",
    descriptionUz: "O'zbek oilasining kulgili sarguzashtlari",
    duration: "1h 35m",
    language: "uz"
  },
  {
    id: "uz004",
    title: "Samarqand sirlari",
    titleUz: "Samarqand sirlari",
    year: 2023,
    genre: ["Adventure", "History"],
    rating: 8.7,
    videoUrl: "https://archive.org/download/SamarqandSirlari/Samarqand%20Sirlari.mp4",
    thumbnail: "https://images.unsplash.com/photo-1596727147705-61a532a659bd?w=400&h=600&fit=crop",
    description: "Samarqandning qadimiy sirlarini ochish haqida",
    descriptionUz: "Samarqandning qadimiy sirlarini ochish haqida",
    duration: "2h 25m",
    language: "uz"
  },

  // English movies
  {
    id: "en001",
    title: "The Shawshank Redemption",
    titleUz: "Shoushenk qamoqxonasidan qochish",
    year: 1994,
    genre: ["Drama"],
    rating: 9.3,
    videoUrl: "https://archive.org/download/TheShawshankRedemption_201712/The%20Shawshank%20Redemption.mp4",
    thumbnail: "https://images.unsplash.com/photo-1489599515378-c5e96e2c3c3e?w=400&h=600&fit=crop",
    description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
    descriptionUz: "Ikki mahbus bir necha yil davomida do'stlashib, oddiy ezgulik harakatlari orqali taskinlik va nihoyat najot topadilar.",
    duration: "2h 22m",
    language: "en"
  },
  {
    id: "en002",
    title: "The Godfather",
    titleUz: "Krestnyy otets",
    year: 1972,
    genre: ["Crime", "Drama"],
    rating: 9.2,
    videoUrl: "https://archive.org/download/TheGodfather1972/The%20Godfather%20%281972%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=400&h=600&fit=crop",
    description: "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
    descriptionUz: "Uyushgan jinoyat dinastiyasining qarigan patriarxi o'zining yashirin imperiyasini ixtiyorini istaksiz o'g'liga topshiradi.",
    duration: "2h 55m",
    language: "en"
  },
  {
    id: "en003",
    title: "The Dark Knight",
    titleUz: "Qorong'u ritsar",
    year: 2008,
    genre: ["Action", "Crime", "Drama"],
    rating: 9.0,
    videoUrl: "https://archive.org/download/TheDarkKnight2008/The%20Dark%20Knight%20%282008%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1571847140471-1d7766e8f077?w=400&h=600&fit=crop",
    description: "Batman begins his war on crime with his first major enemy being Jack Napier, a criminal who becomes the clownishly homicidal Joker.",
    descriptionUz: "Betmen jinoyatchilikga qarshi urushni boshlaydi, uning birinchi asosiy dushmani Jek Napier bo'lib, u masxaraboz qotil Jokerga aylanadi.",
    duration: "2h 32m",
    language: "en"
  },
  {
    id: "en004",
    title: "Forrest Gump",
    titleUz: "Forrest Gamp",
    year: 1994,
    genre: ["Drama", "Romance"],
    rating: 8.8,
    videoUrl: "https://archive.org/download/ForrestGump1994/Forrest%20Gump%20%281994%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop",
    description: "The presidencies of Kennedy and Johnson through the events of Vietnam, Watergate and other historical events unfold from the perspective of an Alabama man.",
    descriptionUz: "Kennedi va Jonson prezidentligi, Vetnam, Uotergeyt va boshqa tarixiy voqealar Alabama odamining nuqtai nazaridan ochib beriladi.",
    duration: "2h 22m",
    language: "en"
  },

  // Russian movies
  {
    id: "ru001",
    title: "Брат",
    titleUz: "Aka",
    year: 1997,
    genre: ["Crime", "Drama"],
    rating: 8.3,
    videoUrl: "https://archive.org/download/Brat1997/Brat%20%281997%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=400&h=600&fit=crop",
    description: "Молодой человек приезжает в Петербург к своему старшему брату и попадает в криминальный мир 90-х.",
    descriptionUz: "Yosh yigit Peterburgga akasining oldiga kelib, 90-yillardagi jinoyat dunyosiga tushib qoladi.",
    duration: "1h 39m",
    language: "ru"
  },
  {
    id: "ru002",
    title: "Левиафан",
    titleUz: "Leviafan",
    year: 2014,
    genre: ["Drama"],
    rating: 7.6,
    videoUrl: "https://archive.org/download/Leviathan2014/Leviathan%20%282014%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1489599515378-c5e96e2c3c3e?w=400&h=600&fit=crop",
    description: "История простого человека, противостоящего коррумпированной системе власти.",
    descriptionUz: "Korrupsiyaga qarshi kurashayotgan oddiy odamning hikoyasi.",
    duration: "2h 20m",
    language: "ru"
  },
  {
    id: "ru003",
    title: "Андрей Рублёв",
    titleUz: "Andrey Rublev",
    year: 1966,
    genre: ["Biography", "Drama", "History"],
    rating: 8.1,
    videoUrl: "https://archive.org/download/AndreyRublev1966/Andrey%20Rublev%20%281966%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1596727147705-61a532a659bd?w=400&h=600&fit=crop",
    description: "Жизнь и творчество великого русского иконописца Андрея Рублёва.",
    descriptionUz: "Buyuk rus rassom Andrey Rublevning hayoti va ijodi haqida.",
    duration: "3h 25m",
    language: "ru"
  },
  {
    id: "ru004",
    title: "Сталкер",
    titleUz: "Stalker",
    year: 1979,
    genre: ["Drama", "Sci-Fi"],
    rating: 8.1,
    videoUrl: "https://archive.org/download/Stalker1979/Stalker%20%281979%29.mp4",
    thumbnail: "https://images.unsplash.com/photo-1571847140471-1d7766e8f077?w=400&h=600&fit=crop",
    description: "Философская притча о путешествии трёх человек в загадочную Зону.",
    descriptionUz: "Uch kishining sirli Zonaga sayohati haqidagi falsafiy hikoya.",
    duration: "2h 42m",
    language: "ru"
  }
];
