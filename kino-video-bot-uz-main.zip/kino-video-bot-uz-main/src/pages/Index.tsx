
import React, { useState } from 'react';
import { Bot, Film, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import TelegramBot from '@/components/TelegramBot';
import MovieCatalog from '@/components/MovieCatalog';
import LanguageSelector from '@/components/LanguageSelector';
import { useLanguage } from '@/contexts/LanguageContext';

const Index = () => {
  const [activeView, setActiveView] = useState<'home' | 'bot' | 'catalog'>('home');
  const { t, language } = useLanguage();

  console.log('Current language:', language);

  if (activeView === 'bot') {
    return (
      <div className="min-h-screen bg-gray-100">
        <div className="max-w-lg mx-auto">
          <div className="p-4 bg-white border-b">
            <Button 
              variant="ghost" 
              onClick={() => setActiveView('home')}
              className="mb-2"
            >
              ← {t('back')}
            </Button>
          </div>
          <TelegramBot />
        </div>
      </div>
    );
  }

  if (activeView === 'catalog') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="p-4 bg-white border-b shadow-sm">
          <Button 
            variant="ghost" 
            onClick={() => setActiveView('home')}
            className="mb-2"
          >
            ← {t('back')}
          </Button>
        </div>
        <MovieCatalog onMovieSearch={setActiveView} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 flex items-center justify-center p-4">
      {/* Language Selector - Top Right */}
      <div className="absolute top-4 right-4">
        <LanguageSelector />
      </div>

      <div className="max-w-4xl mx-auto text-center">
        {/* Hero Section */}
        <div className="mb-12">
          <div className="mb-6">
            <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <Bot className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
              Cine Zap Code Bot
            </h1>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto leading-relaxed">
              {t('heroDescription')}
            </p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="bg-white bg-opacity-10 backdrop-blur-md border-white border-opacity-20 hover:bg-opacity-20 transition-all duration-300 transform hover:scale-105">
            <CardContent className="p-8 text-center">
              <Bot className="w-16 h-16 text-white mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-3">Kinoni topish</h3>
              <p className="text-blue-100 mb-6 leading-relaxed">
                {t('botDescription')}
              </p>
              <Button 
                onClick={() => setActiveView('bot')}
                className="bg-white text-blue-600 hover:bg-blue-50 font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                {t('useBot')}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-white bg-opacity-10 backdrop-blur-md border-white border-opacity-20 hover:bg-opacity-20 transition-all duration-300 transform hover:scale-105">
            <CardContent className="p-8 text-center">
              <Film className="w-16 h-16 text-white mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-3">{t('movieCatalog')}</h3>
              <p className="text-blue-100 mb-6 leading-relaxed">
                {t('catalogDescription')}
              </p>
              <Button 
                onClick={() => setActiveView('catalog')}
                className="bg-white text-purple-600 hover:bg-purple-50 font-semibold px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                {t('viewCatalog')}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="bg-white bg-opacity-10 backdrop-blur-md border-white border-opacity-20 max-w-2xl mx-auto">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-white mb-6">📋 {t('howToUse')}</h3>
            <div className="space-y-4 text-left">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-white text-blue-600 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">
                  1
                </div>
                <p className="text-blue-100">
                  <strong className="text-white">{t('step1Title')}:</strong> {t('step1Description')}
                </p>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-white text-blue-600 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">
                  2
                </div>
                <p className="text-blue-100">
                  <strong className="text-white">{t('step2Title')}:</strong> {t('step2Description')}
                </p>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-white text-blue-600 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">
                  3
                </div>
                <p className="text-blue-100">
                  <strong className="text-white">{t('step3Title')}:</strong> {t('step3Description')}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Creator Footer */}
        <div className="mt-12 text-center">
          <p className="text-blue-200 text-sm">
            💡 Yaratuvchi: Sunnatillo
          </p>
        </div>
      </div>
    </div>
  );
};

export default Index;
