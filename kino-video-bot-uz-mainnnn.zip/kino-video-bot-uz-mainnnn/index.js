import TelegramBot from 'node-telegram-bot-api';

// Bot tokeningizni kiriting
const token = '7871629317:AAEPtwFm68D_sjJCYmeAjkP35fACDNztLU4';
const bot = new TelegramBot(token, { polling: true });

// /start komandasi
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;

  const welcomeMessage = `🇺🇿 Kinolarni qidirish uchun pastdagi tugmani bosing.
🇺🇸 Click the button below to search for movies.
🇷🇺 Нажмите кнопку ниже, чтобы найти фильмы.`;

  const options = {
    reply_markup: {
      inline_keyboard: [[
        {
          text: "🎬 Kinoni ko'rish",
          web_app: {
            url: "https://cine-zip-code-bot.lovable.app/"
          }
        }
      ]]
    }
  };

  bot.sendMessage(chatId, welcomeMessage, options);
});

console.log('Bot ishga tushdi...');
