import React, { useState } from 'react';
import { Search, Star, Clock, Search as SearchIcon, Check } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { moviesDatabase, Movie } from '@/data/movies';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguageSelector from '@/components/LanguageSelector';
import GenreFilter from '@/components/GenreFilter';

interface MovieCatalogProps {
  onMovieSearch?: (view: 'bot') => void;
}

const MovieCatalog = ({ onMovieSearch }: MovieCatalogProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchedCode, setSearchedCode] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const { toast } = useToast();
  const { t, language } = useLanguage();

  const handleGenreSelect = (genre: string | null) => {
    setSelectedGenre(genre);
  };

  // Filter movies by current language, search term, and selected genre
  const filteredMovies = moviesDatabase.filter(movie => {
    const matchesLanguage = movie.language === language;
    const matchesSearch = movie.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movie.titleUz.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movie.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movie.genre.some(g => g.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesGenre = !selectedGenre || 
      movie.genre.some(movieGenre => 
        movieGenre.toLowerCase().includes(selectedGenre.toLowerCase()) ||
        selectedGenre.toLowerCase().includes(movieGenre.toLowerCase())
      );
    
    return matchesLanguage && matchesSearch && matchesGenre;
  });

  const searchMovie = (code: string) => {
    // Store the movie code for bot input
    localStorage.setItem('movieSearchCode', code);
    setSearchedCode(code);
    toast({
      title: "Kino topildi!",
      description: `${code} kodi bot sahifasiga yuborildi`,
    });
    // Redirect to bot view
    if (onMovieSearch) {
      setTimeout(() => {
        onMovieSearch('bot');
      }, 1000);
    }
  };

  const getDisplayTitle = (movie: Movie) => {
    if (language === 'uz') return movie.titleUz;
    return movie.title;
  };

  const getDisplayDescription = (movie: Movie) => {
    if (language === 'uz') return movie.descriptionUz;
    return movie.description;
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Language Selector - Top Right */}
      <div className="absolute top-4 right-4">
        <LanguageSelector />
      </div>

      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">🎬 {t('movieCatalog')}</h1>
        <p className="text-gray-600 mb-6">
          {t('catalogInstruction')}
        </p>
        
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 rounded-full border-gray-300 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Genre Filter */}
      <GenreFilter 
        selectedGenre={selectedGenre}
        onGenreSelect={handleGenreSelect}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMovies.map((movie) => (
          <Card key={movie.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative">
              <img
                src={movie.thumbnail}
                alt={getDisplayTitle(movie)}
                className="w-full h-64 object-cover"
              />
              <div className="absolute top-4 left-4">
                <div className="bg-black bg-opacity-70 text-white px-3 py-1 rounded-full text-sm font-mono">
                  {movie.id}
                </div>
              </div>
              <div className="absolute top-4 right-4">
                <div className="bg-yellow-500 text-black px-2 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-current" />
                  {movie.rating}
                </div>
              </div>
            </div>
            
            <CardHeader className="pb-2">
              <CardTitle className="text-lg leading-tight">
                {getDisplayTitle(movie)}
              </CardTitle>
              <p className="text-sm text-gray-600">{movie.year}</p>
            </CardHeader>
            
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-1">
                {movie.genre.map((genre) => (
                  <Badge key={genre} variant="secondary" className="text-xs">
                    {genre}
                  </Badge>
                ))}
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="w-4 h-4" />
                <span>{movie.duration}</span>
              </div>
              
              <p className="text-sm text-gray-700 line-clamp-3">
                {getDisplayDescription(movie)}
              </p>
              
              <div className="flex gap-2 pt-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => searchMovie(movie.id)}
                  className="w-full"
                >
                  {searchedCode === movie.id ? <Check className="w-4 h-4 mr-1" /> : <SearchIcon className="w-4 h-4 mr-1" />}
                  {searchedCode === movie.id ? "Yuborildi" : "Kinoni qidirish"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMovies.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">{t('noMoviesFound')}</p>
        </div>
      )}
    </div>
  );
};

export default MovieCatalog;
