import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Video, Clock, Star, Download, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { moviesDatabase, Movie } from '@/data/movies';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguageSelector from '@/components/LanguageSelector';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  movie?: Movie;
  type: 'text' | 'video' | 'movie_info' | 'download' | 'movie_image';
}

const TelegramBot = () => {
  const { t, getMovieTitle, language } = useLanguage();
  
  const getFilteredMovies = () => {
    return moviesDatabase.filter(movie => movie.language === language);
  };
  
  const getInitialMessage = () => {
    const filteredMovies = getFilteredMovies();
    const movieList = filteredMovies.map(movie => 
      `${movie.id} - ${getMovieTitle(movie.id)}`
    ).join('\n');
    
    return `${t('greeting')}\n\n${t('availableCodes')}:\n${movieList}`;
  };

  const loadMessages = (): Message[] => {
    try {
      const savedMessages = localStorage.getItem('telegram-bot-messages');
      if (savedMessages) {
        const parsedMessages = JSON.parse(savedMessages);
        return parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        }));
      }
    } catch (error) {
      console.error('Error loading messages from localStorage:', error);
    }
    
    return [{
      id: '1',
      text: getInitialMessage(),
      isBot: true,
      timestamp: new Date(),
      type: 'text'
    }];
  };

  const saveMessages = (messages: Message[]) => {
    try {
      localStorage.setItem('telegram-bot-messages', JSON.stringify(messages));
    } catch (error) {
      console.error('Error saving messages to localStorage:', error);
    }
  };

  const [messages, setMessages] = useState<Message[]>(loadMessages);
  const [inputText, setInputText] = useState('');
  const [downloadingMovies, setDownloadingMovies] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    saveMessages(messages);
  }, [messages]);

  useEffect(() => {
    const searchCode = localStorage.getItem('movieSearchCode');
    if (searchCode) {
      setInputText(searchCode);
      localStorage.removeItem('movieSearchCode');
    }
  }, []);

  useEffect(() => {
    setMessages(prev => {
      const updatedMessages = prev.map((msg, index) => 
        index === 0 ? { ...msg, text: getInitialMessage() } : msg
      );
      return updatedMessages;
    });
  }, [t, getMovieTitle, language]);

  const findMovieByCode = (code: string): Movie | undefined => {
    const filteredMovies = getFilteredMovies();
    return filteredMovies.find(movie => movie.id === code);
  };

  const addMessage = (text: string, isBot: boolean, movie?: Movie, type: 'text' | 'video' | 'movie_info' | 'download' | 'movie_image' = 'text') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      isBot,
      timestamp: new Date(),
      movie,
      type
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const simulateMovieDelivery = (movie: Movie) => {
    setDownloadingMovies(prev => new Set(prev).add(movie.id));
    
    setTimeout(() => {
      addMessage(
        `📥 ${t('downloadingFile').replace('{title}', getMovieTitle(movie.id))}\n📦 ${t('fileSize')}\n⏱️ ${t('estimatedTime')}`,
        true,
        movie,
        'download'
      );
      
      setTimeout(() => {
        setDownloadingMovies(prev => {
          const newSet = new Set(prev);
          newSet.delete(movie.id);
          return newSet;
        });
        
        addMessage(
          `🎬 ${getMovieTitle(movie.id)} (${movie.year})\n⭐ Reyting: ${movie.rating}/10\n🎭 Janr: ${movie.genre.join(', ')}\n⏱️ Davomiyligi: ${movie.duration}`,
          true,
          movie,
          'movie_image'
        );
      }, 3000);
    }, 1000);
  };

  const detectGreetingLanguage = (text: string): 'uz' | 'en' | 'ru' | null => {
    const lowerText = text.toLowerCase();
    
    const uzbekGreetings = ['salom', 'assalom', 'assalomu alaykum'];
    if (uzbekGreetings.some(greeting => lowerText.includes(greeting))) {
      return 'uz';
    }
    
    const englishGreetings = ['hello', 'hi'];
    if (englishGreetings.some(greeting => lowerText.includes(greeting))) {
      return 'en';
    }
    
    const russianGreetings = ['привет', 'здравствуйте'];
    if (russianGreetings.some(greeting => lowerText.includes(greeting))) {
      return 'ru';
    }
    
    return null;
  };

  const getGreetingResponse = (detectedLang: 'uz' | 'en' | 'ru'): string => {
    const filteredMovies = getFilteredMovies();
    const movieList = filteredMovies.map(movie => 
      `${movie.id} - ${getMovieTitle(movie.id)}`
    ).join('\n');

    switch (detectedLang) {
      case 'uz':
        return `👋 Assalomu alaykum! Cine Zap Code Bot ga xush kelibsiz!\n\n🎬 Kino kodini yozing va men sizga kinoni yuboraman.\n\n📝 Mavjud kino kodlari:\n${movieList}`;
      case 'en':
        return `👋 Hello! Welcome to Cine Zap Code Bot!\n\n🎬 Send me a movie code and I'll send you the movie.\n\n📝 Available movie codes:\n${movieList}`;
      case 'ru':
        return `👋 Здравствуйте! Добро пожаловать в Cine Zap Code Bot!\n\n🎬 Отправьте мне код фильма, и я пришлю вам кино.\n\n📝 Доступные коды фильмов:\n${movieList}`;
      default:
        return `👋 Assalomu alaykum! Cine Zap Code Bot ga xush kelibsiz!\n\n🎬 Kino kodini yozing va men sizga kinoni yuboraman.\n\n📝 Mavjud kino kodlari:\n${movieList}`;
    }
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    addMessage(inputText, false);

    setTimeout(() => {
      const userInput = inputText.trim();
      
      const greetingLanguage = detectGreetingLanguage(userInput);
      if (greetingLanguage) {
        addMessage(getGreetingResponse(greetingLanguage), true);
        setInputText('');
        return;
      }

      const movieCode = userInput;
      const movie = findMovieByCode(movieCode);

      if (movie) {
        const movieTitle = getMovieTitle(movie.id);
        const description = language === 'uz' ? movie.descriptionUz : movie.description;
        
        addMessage(
          `📽️ ${movieTitle} (${movie.year})\n⭐ ${t('rating')}: ${movie.rating}/10\n🎭 ${t('genre')}: ${movie.genre.join(', ')}\n⏱️ ${t('duration')}: ${movie.duration}\n\n📖 ${description}`,
          true,
          movie,
          'movie_info'
        );

        setTimeout(() => {
          simulateMovieDelivery(movie);
        }, 1500);
      } else {
        const filteredMovies = getFilteredMovies();
        const movieList = filteredMovies.map(movie => 
          `${movie.id} - ${getMovieTitle(movie.id)}`
        ).join('\n');
        
        addMessage(
          `❌ ${t('codeNotFound').replace('{code}', movieCode)}\n\n${t('availableCodesError')}:\n${movieList}\n\n${t('enterCorrectCode')}`,
          true
        );
      }
    }, 1000);

    setInputText('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-gradient-to-b from-blue-50 to-blue-100 flex flex-col" style={{ height: 'calc(100vh - 80px)' }}>
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg flex-shrink-0">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-lg">Kinoni topish</h1>
              <p className="text-blue-200 text-sm">Online</p>
            </div>
          </div>
          <LanguageSelector />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isBot ? 'justify-start' : 'justify-end'} mb-4`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                message.isBot
                  ? 'bg-white text-gray-800 rounded-bl-md shadow-md'
                  : 'bg-blue-600 text-white rounded-br-md shadow-md'
              }`}
            >
              {message.type === 'download' && message.movie ? (
                <div className="space-y-3">
                  <div className="flex items-start gap-2 mb-2">
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Download className="w-5 h-5 text-blue-600 animate-bounce" />
                    <span className="font-semibold">{t('downloading')}</span>
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3">
                    <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                      <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{width: '45%'}}></div>
                    </div>
                    <p className="text-sm text-gray-600">{message.text}</p>
                  </div>
                </div>
              ) : message.type === 'movie_image' && message.movie ? (
                <div className="space-y-3">
                  <div className="flex items-start gap-2 mb-2">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <p className="whitespace-pre-line leading-relaxed text-green-700 font-medium mb-3">✅ Kino tayyor!</p>
                  <Card className="p-0 overflow-hidden border-green-200">
                    <div className="relative">
                      <img
                        src={message.movie.thumbnail}
                        alt={message.movie.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                        <div className="text-center text-white">
                          <Video className="w-12 h-12 mx-auto mb-2" />
                          <p className="text-sm">🎬 Kino</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-sm text-gray-600">{message.text}</p>
                    </div>
                  </Card>
                </div>
              ) : (
                <>
                  <div className="flex items-start gap-2 mb-2">
                    {message.isBot && (
                      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}
                    {!message.isBot && (
                      <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ml-auto">
                        <User className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                  <p className="whitespace-pre-line leading-relaxed">{message.text}</p>
                  {message.movie && message.type === 'movie_info' && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <img
                        src={message.movie.thumbnail}
                        alt={message.movie.title}
                        className="w-full h-32 object-cover rounded-lg mb-2"
                      />
                      <div className="flex flex-wrap gap-1">
                        {message.movie.genre.map((g) => (
                          <Badge key={g} variant="outline" className="text-xs">
                            {g}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
              <div className="text-xs opacity-70 mt-2">
                {message.timestamp.toLocaleTimeString('uz-UZ', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t flex-shrink-0">
        <div className="flex gap-2">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={t('enterMovieCode')}
            className="flex-1 rounded-full border-gray-300 focus:border-blue-500"
          />
          <Button 
            onClick={handleSendMessage}
            size="icon"
            className="rounded-full bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TelegramBot;
